package searchers.interfaces;

import org.apache.lucene.index.IndexReader;

import utils.Search;

public interface Searcher {
	public void setQuery(String query);
	public Search doSearch(int numPages,int hitsPerPage,IndexReader reader);
	
}
