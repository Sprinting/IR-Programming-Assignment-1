package searchers;

import org.apache.lucene.index.IndexReader;

import searchers.interfaces.Searcher;
import utils.Search;

public class SearcherImpl implements Searcher {
	private String query;
	private Search search;
	@Override
	public void setQuery(String query) {
		this.query = query;
	}

	@Override
	public Search doSearch(int numPages, int hitsPerPage,IndexReader reader) {
		search = new Search(reader,numPages,hitsPerPage,query);
		return search;
	}

}
