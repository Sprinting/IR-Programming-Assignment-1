package api.commandLine;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Optional;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.TopDocs;

import indexers.BasicIndexer;
import searchers.SearcherImpl;
import searchers.interfaces.Searcher;
import utils.Filename;
import utils.FilenameImpl;
import utils.Search;

public class CommandLineAPI {

	public static void run(String documents_folder, Boolean reIndex, String idxPath, String query) {
		BasicIndexer indexer;
		if (reIndex) {
			indexer = new BasicIndexer(new File(documents_folder).toPath(), true,
					new File(idxPath).toPath());

		} else {
			indexer = new BasicIndexer(new File(documents_folder).toPath(), false, new File(idxPath).toPath());

		}
		Optional<IndexReader> reader = indexer.getIndexReader();
		if (reader.isPresent()) {
			Searcher searcher = new SearcherImpl();
			searcher.setQuery(query);
			if (reader.isPresent()) {
				Search search = searcher.doSearch(10, 5, reader.get());
				Optional<TopDocs> results = search.getSearchResultsIfAny();
				if (results.isPresent()) {
					/*
					 * 1) Print ranked list of search documents.
					 * 
					 */
					TopDocs hits = results.get();
					
					for (int i = 0; i < hits.totalHits.value; i++) {

						int rank = i;
						Document document;
						try {
							document = search.getSearcher().doc(hits.scoreDocs[rank].doc);
							float score = hits.scoreDocs[rank].score;
							String path = document.get(BasicIndexer._PATH);
							String lastModified = document.get(BasicIndexer.LAST_MODIFIED_STORED);
							Date lastModifiedDate = new Date(Long.parseLong(lastModified));
							lastModified = lastModifiedDate.toString();
							String title = document.get(BasicIndexer._TITLE);
							String summary = document.get(BasicIndexer._SUMMARY);
							String date = document.get(BasicIndexer._DATE);
							StringBuilder queryResult = new StringBuilder("");
//							System.out.println(document.get(BasicIndexer.FULL_NAME));
							System.out.println(document.get(BasicIndexer._PATH));
							queryResult.append("|Rank: ").append(rank).append("|Relevance Score: ").append(score)
									.append("|Path: ").append(path).append("|last modified: ").append(lastModified);
									
							Filename filename = new FilenameImpl(new File(path).toPath());
							String extension = filename.getExtension().get();
							if(extension.toLowerCase().endsWith("htm") 
									||extension.toLowerCase().endsWith("html"))
							{
								queryResult.append("|Title: ").append(title)
								.append("|Date: ").append(date).append("|Summary: ").append(summary);
							}
							System.out.println("|---|");
							System.out.println(queryResult);
							System.out.println("|---|");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
				}
			}

		}
	}
}