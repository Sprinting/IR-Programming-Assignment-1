package utils;

import java.io.IOException;
import java.util.Optional;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser.Operator;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;

import indexers.BasicIndexer;

public class Search {
	/*
	 * Print a ranked list of relevant articles given a search query. The output should
	 * contain the most relevant documents, their rank, path, last modification time,
	 * relevance score and in addition for HTML documents title and summary
	 */
	Optional<TopDocs> results;
	Optional<ScoreDoc[]> hits;
	IndexSearcher searcher;

	public Search(IndexReader reader,int numPages,int hitsPerPage,String queryString){
		searcher = new IndexSearcher(reader);
		Analyzer analyzer = new EnglishAnalyzer(EnglishAnalyzer.getDefaultStopSet());
		
		MultiFieldQueryParser mfqParser = new MultiFieldQueryParser(BasicIndexer._INDEXED_FIELDS, analyzer);
		mfqParser.setDefaultOperator(Operator.AND);
		Query query;
		try {
			query = mfqParser.parse(queryString);
			System.out.println(query+ " "+numPages*hitsPerPage);
			results = Optional.of(searcher.search(query, numPages*hitsPerPage));
			if(results.isPresent())
			{
				hits = Optional.of(results.get().scoreDocs);
			}
			else {
				hits = Optional.ofNullable(null);
			}
			
			
			
		} catch (ParseException e) {
			results = Optional.ofNullable(null);
			hits = Optional.ofNullable(null);
			e.printStackTrace();
		}
		catch (IOException e) {
			results = Optional.ofNullable(null);
			hits = Optional.ofNullable(null);
			e.printStackTrace();
		}

	}
	
	public Optional<TopDocs> getSearchResultsIfAny(){
		return results;
	}
	public Optional<ScoreDoc[]> getHitsIfAny(){
		return hits;
	}
	
	public IndexSearcher getSearcher()
	{
		return searcher;	
	}
}
