package utils;

public enum FileType {
	HTML("html"), TEXT("txt"), HTM("htm");

	private final String type;

	FileType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	};

}
