package utils;

import java.util.Optional;

public interface Filename {
	public Optional<String> getExtension();
	public Optional<String> getBaseName();
	public Optional<String> getNameWithExtension();
	public String getAbsolutePath();
}
