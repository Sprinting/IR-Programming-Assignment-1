package utils;

import java.nio.file.Path;
import java.util.Optional;

import org.apache.commons.io.FilenameUtils;

public class FilenameImpl implements Filename {
	Path file;
	public FilenameImpl(Path file) {
		this.file = file;
	}

	@Override
	public Optional<String> getExtension() {
		try{
			return Optional.of(FilenameUtils.getExtension(file.getFileName().toString()));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return Optional.ofNullable(null);
		}
	}

	@Override
	public Optional<String> getBaseName() {
		try{
			return Optional.of(FilenameUtils.getBaseName(file.getFileName().toString()));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return Optional.ofNullable(null);
		}
	}

	@Override
	public Optional<String> getNameWithExtension() {
		try{
			return Optional.of(FilenameUtils.getName(file.getFileName().toString()));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return Optional.ofNullable(null);
		}
	}

	@Override
	public String getAbsolutePath() {
		return file.toAbsolutePath().toString();
	}

}
