package indexers;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Optional;

import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.NumericDocValuesField;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import parsers.impl.HTMLDocumentParser;
import parsers.impl.TextDocumentParser;
import parsers.interfaces.DocumentParser;
import utils.FileType;
import utils.Filename;
import walker.impl.FileWalkerImpl;
import walker.interfaces.FileWalker;

public class BasicIndexer {

	public static final String _TITLE = "title";
	public static final String _DATE = "date";
	public static final String LAST_MODIFIED = "lastModified";
	public static final String LAST_MODIFIED_STORED = "lastModifiedStored";
	public static final String _SUMMARY = "summary";
	public static final String _BODY = "body";
	public static final String FULL_NAME = "fullName";
	public static final String BASE_NAME = "baseName";
	public static final String _PATH = "path";
	
	public static final String[] _INDEXED_FIELDS = {
			_TITLE,
			_DATE,
			LAST_MODIFIED,
			LAST_MODIFIED_STORED,
			_SUMMARY,
			_BODY,
			FULL_NAME,
			BASE_NAME,
			_PATH
			
	};
	public Optional<IndexReader> maybeIndexReader;
	public BasicIndexer(Path target, Boolean createNewIndex, Path indexDirectory) {
		if (createNewIndex && null != indexDirectory) {
			FileWalker walker = new FileWalkerImpl(target);
			// this.maybeFileMap = Optional.of(walker.getFileMap());
			this.maybeIndexReader = Optional.ofNullable(null);

			/*
			 * Create an Index
			 */
			EnglishAnalyzer analyzer = new EnglishAnalyzer(EnglishAnalyzer.getDefaultStopSet());
						
			IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
			iwc.setOpenMode(OpenMode.CREATE);
			Directory dir=null;
			try {
				dir = FSDirectory.open(indexDirectory);
				final IndexWriter writer = new IndexWriter(dir, iwc);
				walker.getFileMap().forEach((path, type) -> {
					Document doc = new Document();
					DocumentParser parser = null;
					if (type.equals(FileType.HTML) || type.equals(FileType.HTM)) {
						parser = new HTMLDocumentParser(path);
					} else if (type.equals(FileType.TEXT)) {
						parser = new TextDocumentParser(path);
					}

					if (parser.getFilename().isPresent()) {
						Filename filename = parser.getFilename().get();
						String absPath = filename.getAbsolutePath();
						String baseName = "";
						String fullName = "";

						if (filename.getBaseName().isPresent()) {
							baseName = filename.getBaseName().get();
						}
						if (filename.getNameWithExtension().isPresent()) {
							fullName = filename.getNameWithExtension().get();
						}

						String body = "";

						if (parser.getBody().isPresent()) {
							body = parser.getBody().get();
						}

						String title = "";

						if (parser.getTitle().isPresent()) {
							title = parser.getTitle().get();
						}

						String date = "";

						if (parser.getDate().isPresent()) {
							date = parser.getDate().get();
						}

						Long lastModifiedTime = 0L;

						if (parser.getLastModified().isPresent()) {
							lastModifiedTime = parser.getLastModified().get().getTime();
						}

						String summary = "";

						if (parser.getSummary().isPresent()) {
							summary = parser.getSummary().get();
						}

						Field _path = new StringField(_PATH, absPath, Field.Store.YES);
						Field _base_name = new TextField(BASE_NAME, baseName.toString(), Field.Store.YES);
						Field _full_name = new TextField(FULL_NAME, fullName.toString(), Field.Store.YES);
						Field _body = new TextField(_BODY, body, Field.Store.NO);
						Field _title = new TextField(_TITLE, title, Field.Store.YES);
						Field _date = new StringField(_DATE, date, Field.Store.NO);
						Field _last_modified = new NumericDocValuesField(LAST_MODIFIED, lastModifiedTime);
						Field _last_modified_stored = new StoredField(LAST_MODIFIED_STORED, lastModifiedTime);
						Field _summary = new TextField(_SUMMARY, summary, Field.Store.YES);

				
						
						doc.add(_path);
						doc.add(_base_name);
						doc.add(_full_name);
						doc.add(_body);
						doc.add(_title);
						doc.add(_date);
						doc.add(_last_modified);
						doc.add(_last_modified_stored);
						doc.add(_summary);

						
						try  {
							System.out.println("adding..."+path.toAbsolutePath().toString());
							writer.addDocument(doc);
						} catch (Exception e1) {
							e1.printStackTrace();
						}

					}

				});
				writer.close();
			} catch (IOException e2) {
				e2.printStackTrace();
				
			}
			
			
			
			try {
				Directory _dir = FSDirectory.open(indexDirectory);
				IndexReader reader = DirectoryReader.open(_dir);
				this.maybeIndexReader = Optional.of(reader);
				// return the index reader

			} catch (IOException e) {
				this.maybeIndexReader = Optional.ofNullable(null);
				e.printStackTrace();
			}
		} else if(null!=indexDirectory) {
			// this.maybeFileMap = Optional.ofNullable(null);
			// Don't create a new Index
			try {
				Directory directory = FSDirectory.open(indexDirectory);
				IndexReader idxReader = DirectoryReader.open(directory);
				this.maybeIndexReader = Optional.of(idxReader);
			} catch (IOException e) {
				this.maybeIndexReader = Optional.ofNullable(null);
				e.printStackTrace();
			}
		}
	}

	public Optional<IndexReader> getIndexReader() {
		return maybeIndexReader;
	}
}
