package main;

import java.io.IOException;
import java.util.Arrays;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

import api.commandLine.CommandLineAPI;

public class Runner {

	@Option(name = "-ri", aliases = "--reindex", usage = "True if you want to make a new Index")
	private Boolean reIndex;

	@Option(name = "-idx", aliases = "--index_dir", usage = "Location of an existing index to use.")
	private String idxPath;

	@Option(name = "-q", aliases = "--query", usage = "Your search query.")
	private String query;

	public void setup(String[] args) throws IOException {
		CmdLineParser parser = new CmdLineParser(this);
		try {
			parser.parseArgument(args);

		} catch (CmdLineException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		Runner runner = new Runner();
		try {
			String[] argsForJArgs = Arrays.copyOfRange(args, 1,args.length);
			runner.setup(argsForJArgs);
			CommandLineAPI.run(args[0], runner.reIndex, runner.idxPath, runner.query);
		} catch (IOException e) {
			e.printStackTrace();
		}


	}

}