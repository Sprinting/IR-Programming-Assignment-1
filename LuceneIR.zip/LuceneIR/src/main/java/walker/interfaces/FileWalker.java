package walker.interfaces;

import java.nio.file.Path;
import java.util.Map;

import utils.FileType;

public interface FileWalker {

	public Map<Path,FileType> getFileMap();
}
