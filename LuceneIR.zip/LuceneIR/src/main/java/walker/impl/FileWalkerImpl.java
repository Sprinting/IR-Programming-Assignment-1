package walker.impl;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import utils.FileType;
import utils.Filename;
import utils.FilenameImpl;
import walker.interfaces.FileWalker;

public class FileWalkerImpl implements FileWalker {

	Map<Path, FileType> fileList;

	public FileWalkerImpl(Path target) {
		fileList = new HashMap<Path, FileType>();
		if (Files.isDirectory(target)) {
			try {
				Files.walkFileTree(target, new SimpleFileVisitor<Path>() {
					@Override
					public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
						Filename name = new FilenameImpl(file);
						Optional<String> ext = name.getExtension();
						if (ext.isPresent()) {
							if (FileType.HTML.getType().equals(ext.get())) {
								fileList.put(file, FileType.HTML);
							} else if (FileType.TEXT.getType().equals(ext.get())) {
								fileList.put(file, FileType.TEXT);
							}
						}
						return FileVisitResult.CONTINUE;

					}
				});
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public Map<Path, FileType> getFileMap() {
		return fileList;
	}
}
