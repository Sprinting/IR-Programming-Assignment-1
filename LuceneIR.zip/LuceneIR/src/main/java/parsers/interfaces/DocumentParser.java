package parsers.interfaces;

import java.util.Date;
import java.util.Optional;

import utils.Filename;

public interface DocumentParser {
	public static final int SUMMARY_LENGTH = 100;
	public static final String LAST_MODIFIED_TIME = "lastModifiedTime";
	public static final String DATE_TAG = "date";
	
	
	public Optional<String> getTitle();
	public Optional<String> getDate();
	public Optional<Date> getLastModified();
	public Optional<String> getBody();
	public Optional<String> getSummary();
	public Optional<Filename> getFilename();
}