package parsers.impl;

import java.util.Date;
import java.util.Optional;

import parsers.interfaces.DocumentParser;
import utils.Filename;

public abstract class AbstractParser implements DocumentParser {

	public static final void printParserInformation(DocumentParser parser){
		System.out.println("Title "+parser.getTitle());
		System.out.println("Body "+parser.getBody());
		System.out.println("Date" +parser.getDate());
		parser.getFilename().ifPresent(f->System.out.println("base name"+ f.getBaseName()));
		parser.getFilename().ifPresent(f->System.out.println("extension "+f.getExtension()));
		parser.getFilename().ifPresent(f->System.out.println("full name "+f.getNameWithExtension()));
		System.out.println("last modified "+ parser.getLastModified());
		System.out.println("summary "+parser.getSummary());
	}
	
	@Override
	public Optional<String> getTitle() {
		return null;
	}

	@Override
	public Optional<String> getDate() {
		return null;
	}

	@Override
	public Optional<Date> getLastModified() {
		return null;
	}

	@Override
	public Optional<String> getBody() {
		return null;
	}

	@Override
	public Optional<String> getSummary() {
		return null;
	}

	@Override
	public Optional<Filename> getFilename() {
		return null;
	}

}
