package parsers.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;


import parsers.interfaces.DocumentParser;
import utils.Filename;
import utils.FilenameImpl;

public class TextDocumentParser extends AbstractParser implements DocumentParser {
	private Optional<String> title;
	private Optional<String> body;
	private Optional<Filename> filename;
	private Optional<Date> lastModified;
	private Optional<String> date;
	private Optional<String> summary;
	
	private static  int MAX_SUMMARY_LINES = 3;
	
	public TextDocumentParser(Path path) {
		title = Optional.ofNullable(null);
		body = Optional.ofNullable(null);
		filename =Optional.ofNullable(null);
		lastModified = Optional.ofNullable(null);
		date = Optional.ofNullable(null);
		summary = Optional.ofNullable(null);
		if(Files.exists(path)){
			if(Files.isRegularFile(path) && Files.isReadable(path))
			{
				try{
					FileTime fileTime = (FileTime) Files.getAttribute(path, LAST_MODIFIED_TIME);
					Date lastModifiedDate = new Date(fileTime.toMillis());
					List<String> textDocument = Files.readAllLines(path);
					if(!textDocument.isEmpty()){
						body = Optional.of(String.join("\n", textDocument));
						StringBuilder summaryBuilder  = new StringBuilder();
						int numLines = textDocument.size()>MAX_SUMMARY_LINES?MAX_SUMMARY_LINES:textDocument.size();
						for(int i = 0; i<numLines;i++){
							summaryBuilder.append(textDocument.get(i));
						}
						summary = Optional.of(summaryBuilder.toString());
					}
					filename = Optional.of(new FilenameImpl(path));
					lastModified = Optional.of(lastModifiedDate);
					date = lastModified.isPresent()?Optional.of(lastModified.get().toString()):Optional.ofNullable(null);
					
					
					
				}
				catch(IOException documentReadingException){
					documentReadingException.printStackTrace();
					
				}
			}
		}
	}
	@Override
	public Optional<String> getTitle() {
		return title;
	}

	@Override
	public Optional<String> getDate() {
		return date;
	}

	@Override
	public Optional<Date> getLastModified() {
		return lastModified;
	}

	@Override
	public Optional<String> getBody() {
		return body;
	}

	@Override
	public Optional<String> getSummary() {
		return summary;
	}

	@Override
	public Optional<Filename> getFilename() {
		return filename;
	}

	

}
