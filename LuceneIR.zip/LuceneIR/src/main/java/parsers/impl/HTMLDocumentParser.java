package parsers.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.Date;
import java.util.Optional;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import parsers.interfaces.DocumentParser;
import utils.Filename;
import utils.FilenameImpl;

public class HTMLDocumentParser extends AbstractParser implements DocumentParser {
	

	private Optional<String> title;
	private Optional<String> body;
	private Optional<Filename> filename;
	private Optional<Date> lastModified;
	private Optional<String> date;
	private Optional<String> summary;
	
	public HTMLDocumentParser(Path path) {
		title = Optional.ofNullable(null);
		body = Optional.ofNullable(null);
		filename =Optional.ofNullable(null);
		lastModified = Optional.ofNullable(null);
		date = Optional.ofNullable(null);
		summary = Optional.ofNullable(null);
		if(Files.exists(path)){
			if(Files.isRegularFile(path) && Files.isReadable(path))
			{
				try{
					Document htmlDocument = Jsoup.parse(path.toFile(),null);
					String textSummary = "";
					
					if(htmlDocument.body().text().length()<SUMMARY_LENGTH){
						textSummary = htmlDocument.body().text();
					}
					else{
						textSummary = htmlDocument.body().text().substring(0,SUMMARY_LENGTH-1);
					}
					FileTime fileTime = (FileTime) Files.getAttribute(path, LAST_MODIFIED_TIME);
					Date lastModifiedDate = new Date(fileTime.toMillis());
					title = Optional.of(htmlDocument.title());
					body = Optional.of(htmlDocument.body().text());
					filename = Optional.of(new FilenameImpl(path));
					lastModified = Optional.of(lastModifiedDate);
					date = Optional.of(htmlDocument.getElementsByTag(DATE_TAG).text());
					summary = Optional.of(textSummary);
				}
				catch(IOException documentReadingException){
					documentReadingException.printStackTrace();
					
				}
			}
		}
		
	}
	@Override
	public Optional<String> getTitle() {
		// TODO Auto-generated method stub
		return title;
	}

	@Override
	public Optional<String> getDate() {
		// TODO Auto-generated method stub
		return date;
	}

	@Override
	public Optional<Date> getLastModified() {
		// TODO Auto-generated method stub
		return lastModified;
	}

	@Override
	public Optional<String> getBody() {
		// TODO Auto-generated method stub
		return body;
	}

	@Override
	public Optional<Filename> getFilename() {
		// TODO Auto-generated method stub
		return filename;
	}
	@Override
	public Optional<String> getSummary() {
		// TODO Auto-generated method stub
		return summary;
	}

}
